#include <stdio.h>
#include <string.h>
#define MAX_EMPLOYEES 30
//do not modify this declaration, not even the sequence.
typedef char string[40];
struct EmployeeTag
{ string name;
 float salary;
 int nID;
};
typedef struct EmployeeTag EmployeeType;

//Function 1: Gets input of 1 Employee
//use scanf!!!
void getInput (EmployeeType *EmployeeInfo)
{
  // change to scanf
  printf("Name: ");
  fgets(EmployeeInfo->name, 40, stdin);
  EmployeeInfo->name[strlen(EmployeeInfo->name)-1] = '\0'; 
  printf("Salary: ");
  scanf("%f", &EmployeeInfo->salary);
  printf("ID: ");
  scanf("%d", &EmployeeInfo->nID);
}

//Function 2:  continuously call the get input function in (a) as long as the user wants to input another employee information and store this employee as part of the binary file of EmployeeType. If the file does not exist, a file is created. If the file does exist, additional entries are added (not overwritten). There is no need to check for duplicate entries

void f2 (string filename, EmployeeType EmployeeInfo[])
{
  FILE *fp;
  int choice=0, i=0;
  char cDump;
  if((fp = fopen(filename, "rb+"))!= NULL)
  {
    fseek(fp,0,SEEK_END);
    do
    {
      getInput(&EmployeeInfo[i]);
      fwrite(&EmployeeInfo[i],sizeof(EmployeeType),1,fp);
      i++;
      printf("Continue [1 = YES/ 2 = NO]\n");
      scanf("%d%c", &choice, &cDump);
      fflush(stdin);
    } while(choice == 1);
    fclose(fp); 
  }
  else
  {
    fp = fopen(filename, "wb");
    do
    {
      getInput(&EmployeeInfo[i]);
      fwrite(&EmployeeInfo[i],sizeof(EmployeeType),1,fp);
      i++;
      printf("Continue [1 = YES/ 2 = NO]\n");
      scanf("%d%c", &choice, &cDump);
      fflush(stdin);
    } while(choice == 1);
    fclose(fp);
  }
}

//Function 3: return the number of EmployeeType entries in the binary file. Only the string filename is accepted as parameter to the function
int f3 (string filename)
{
  int i;
  long int nByte;
  FILE *fp;
  if((fp = fopen(filename, "rb"))!= NULL)
  {
    fseek(fp,0,SEEK_END);
    nByte = ftell(fp);
    i = nByte / sizeof(EmployeeType); 
    fclose(fp);
  }
  else
  printf("File does not exist!");

 return i; 
}

//Function 4:  display the contents of the binary file
void f4 (string filename, int nElem)
{
  FILE *fp;
  int i;
  EmployeeType EmployeeInfo;
  if((fp = fopen(filename, "rb"))!= NULL)
  {
    printf("-EMPLOYEES-\n\n%-20s\t%-10s\t%s\n","Name","Salary","ID");
    for(i=0; i < nElem; i++)
    {
      fread(&EmployeeInfo,sizeof(EmployeeType),1,fp);
      printf ("%-20s\t%-10.2f\t%d\n", EmployeeInfo.name,EmployeeInfo.salary, EmployeeInfo.nID);
    }
    fclose(fp);
    printf("\n");
  }
  else
  printf("File does not exist!");
  
}

//Function 5: open the binary file employee.dat using rb+ mode. Update the employee structures stored in the file by giving a salary increase of 10 percent to all employees.
void f5(string filename, int nElem) 
{
  FILE *fp;
  int i;
  EmployeeType temp; //temp structure
  if((fp = fopen(filename, "rb+"))!= NULL)
  {
    for(i=0; i < nElem; i++)
    { 
      fseek(fp,sizeof(string),SEEK_CUR);
      fread(&temp.salary,sizeof(float),1,fp);
      temp.salary += temp.salary *0.1;
      fseek(fp,- sizeof(float), SEEK_CUR);
      fwrite(&temp.salary,sizeof(float),1,fp);
      fseek(fp,sizeof(int),SEEK_CUR);
    }
  }
}
/* Sort the contents of the binary file by in increasing order of nID. Note that there are no
assumed maximum number of elements in the file, so you CANNOT load everything to an array
first. */
void swap(EmployeeType * e1, EmployeeType * e2)
{
	EmployeeType temp = *e1;
	*e1=*e2;
	*e2=temp;
}

void sort(string filename)
{
  FILE *fp;
  int i,j,e1,e2;
  char ch;
  if((fp = fopen(filename, "rb+"))!= NULL)
  {
    //Read the first two records, swap them if you have to, using a seek to backup up. Then read the next record, swap in needed, and so on. You will repeat this process until you've read the file in its entirety and no swaps were done.
    

    
  }




int main()
{
  string fileName;
  int choice;
  char ch;
  EmployeeType EmployeeInfo[MAX_EMPLOYEES];
  printf("Input FILE HERE: ");
	scanf("%s",fileName);
  do
  {
    printf("MENU:\n\n[1] Add Employees\n[2] Display Employees\n[3] Give 10%% increase to salary\n[4] Sort by ID\n[5] Exit\n\nChoice: ");
    choice = 0;
    scanf("%d%c",&choice, &ch);
  		switch(choice)
  		{
        case 1: f2(fileName,EmployeeInfo);  break;
        case 2: f4(fileName,f3(fileName));  break;
        case 3: f5(fileName,f3(fileName));  break;
        case 4: sort(fileName);             break;
        case 5: break;
        default:
          printf("INVALID INPUT! Press any ENTER to continue\n");
    			getchar();
    			getchar();
    			getchar();
    			fflush(stdin);
    			break;
      }
  }while(choice != 5);
  
}