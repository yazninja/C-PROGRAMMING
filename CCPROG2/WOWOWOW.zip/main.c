/*
Group 6:
Janina Mishi R. Bacay
Yazle Sean S. Ligot
Elisha Nicole R. Angsanto
Matthew Aeiden S. Rogando
*/

#include "candidates.c"

/* Create the main program such that the user is allowed to navigate through a series of menu options until he chooses to exit. The
menu options are:
a . Add Candidate Info : This option will ask 1 candidate information from the user.
b. Display All Candidates : This option will display all candidates (and their respective information) in alphabetical order.
Thus, in this option, the function sortAlphabetical() should be called. The function display() should also be called as part of the
solution. Note that the user is to be asked to press a key (of your choice, like N or Enter) before the information of the next
candidate may be shown.
c. Display By Rating: In this option, the function sortByRating() should first be called. After which, part of the solution
should call function display(). The user is also asked to press a key before the next candidate information will be displayed.
d. Display By Party: Here, the user is asked to input the party to search for. Then, the function displayByParty() is called.
e. Exit : If this option is chosen, the program then terminates properly. Remember that exit() should not be called. */

int main()
{
  arrCandidates aCandidates;
  int i,choice,nCandidates = 0;
  char cDump;
  char party[21];
  do
  {
    cls();
    printf("Array Of Structures Activity\n\n");
    printf("[1] Add Candidate Info\n");
    printf("[2] Display All Candidates\n");
    printf("[3] Display By Rating\n");
    printf("[4] Display by Party\n");
    printf("[5] Exit\n\n");
    printf("Choice: ");
    scanf("%d%c", &choice, &cDump);

    switch(choice)
    {
      case 1:
        cls();
        getInput(&aCandidates[nCandidates]);
        nCandidates++;
        break;
      case 2:
        sortAlphabetical(&aCandidates, nCandidates);
        printf("PASSED!");
        for (i=0; i<nCandidates; i++)
          display(aCandidates[i]);
        break;
      case 3:
        sortByRating(&aCandidates, nCandidates);
        printf("PASSED!");
        for (i=0; i<nCandidates; i++)
          display(aCandidates[i]);
        break;
      case 4:
        fgets(party, 20, stdin);
        sortAlphabetical(&aCandidates, nCandidates);
        displayByParty(aCandidates, nCandidates, party);
        break;
      case 5:
        break;
      default:
        printf("INVALID INPUT! Press ENTER to continue\n");
        getchar();
        fflush(stdin);
        break;
    }
  } while (choice != 5);
  return 0;
}