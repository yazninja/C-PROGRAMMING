/*
Group 6:
Janina Mishi R. Bacay
Yazle Sean S. Ligot
Elisha Nicole R. Angsanto
Matthew Aeiden S. Rogando
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_CANDIDATES 20
void cls()
{
    system("cls||clear");
}
/*
1. Define the data structure to represent an array of at most 20 candidates where each contains the name, birthday, position, party,
a list of at most 10 bills passed, the number of bills passed, and a rating. Note the following as you define the data structure to
represent the model:
a.) name further consists of the first name, last name, and middle initial
b.) birthday further consists of the numeric month, day, and year
c.) each bill passed is a structure that contains the bill and the date it was passed
c.) rating is further defined to contain the percentage of confidence/possible votes from a survey, the organization who
administered the survey, and the date of the survey.
d.) For data types or lengths of strings not explicitly indicated, please make your own intelligent judgement.*/

typedef char String30[31];
struct nameTag
{
  String30 firstName;
  String30 lastName;
  char middleInitial;
};
struct DateTag
{
  int month;
  int day;
  int year;
};
struct BillTag
{
  String30 billName;
  struct DateTag billDate;
} BillPassed;
typedef struct
{
  float surveyPercentage;
  String30 surveyOrganization;
  struct DateTag surveyDate;
} Rating;
struct CandidateTag
{
  struct nameTag name;
  struct DateTag birthdate;
  char position[21];
  char party[21];
  struct BillTag candidateBill[10];
  int numBillsPassed;
  Rating rate;
};
typedef struct CandidateTag arrCandidates[MAX_CANDIDATES];
/*2. Create a function getName() that will get the name of the candidate.*/
void getName(struct nameTag * n)
{
  char cDump;
  printf ("First Name: ");
  scanf ("%s%c", n->firstName, &cDump);
  printf ("Last Name: ");
  scanf ("%s%c", n->lastName, &cDump);
  printf ("Middle Initial: ");
  scanf ("%c%c", &n->middleInitial, &cDump);

}
/* 3. Create a function getDate() that will get the date information. */
void getDate(struct DateTag * d)
{
  char cDump;
  printf ("Month: ");
  scanf ("%d%c", &d->month, &cDump);
  printf ("Day: ");
  scanf ("%d%c", &d->day, &cDump);
  printf ("Year: ");
  scanf ("%d%c", &d->year, &cDump);
  
}
/* 4. Create the function getInput() to now call function to get input from the user. Note that part of the solution in this function is to
call the functions getName() to get the name of the candidate and getDate() to get the birthday and the date the bill was passed. */
void getInput(struct CandidateTag * c)
{
  int i=0;
  char choice, cDump;
  printf("CANDIDATE INFORMATION\n\n");
  printf("---NAME---\n");
  getName(&c->name);
  printf("\n---BIRTHDAY---\n");
  getDate(&c->birthdate);//birthday
  printf("\n---MORE INFO---\n");
  printf ("Position: ");
  scanf("%s%c",c->position, &cDump);
  printf ("Party Name: ");
  fgets(c->party,20,stdin);
  printf("\n---BILLS PASSED---\n");
  do
  {
    printf ("-Bill # %d-\n", i+1);
    printf ("Bill Name: ");
    fgets(c->candidateBill[i].billName,30,stdin);
    printf ("Bill Date: \n");
    getDate(&c->candidateBill[i].billDate);//bill
    printf ("Continue?[Y/N] ");
    fflush(stdin);
    scanf("%c%c",&choice,&cDump);
    c->numBillsPassed++;
    i++;
  } while((choice == 'Y'|| choice == 'y') && c->numBillsPassed < 10);
  printf("\n---RATING---\n");
  printf ("Percentage of Possible votes: ");
  scanf ("%f%c", &c->rate.surveyPercentage, &cDump);
  printf ("Survey Organization Name: ");
  fgets(c->rate.surveyOrganization,30,stdin);
  printf ("Survey Date:\n ");
  getDate(&c->rate.surveyDate);//rating
}

/* 5. Create a function displayDate() that will display the date information in the format of <Month in word form> <day>, <year>. For
example: March 3, 2018 */
void displayDate(struct DateTag d)
{
  if(d.month == 1)
    printf("January");
  else if(d.month == 2)
    printf("February");
  else if(d.month == 3)
    printf("March");
  else if(d.month == 4)
    printf("April");
  else if(d.month == 5)
    printf("May");
  else if(d.month == 6)
    printf("June");
  else if(d.month == 7)
    printf("July");
  else if(d.month == 8)
    printf("August");
  else if(d.month == 9)
    printf("September");
  else if(d.month == 10)
    printf("October");
  else if(d.month == 11)
    printf("November");
  else if(d.month == 12)
    printf("December");
  printf(" %d, %d\n",d.day, d.year);
}

/* 6. Create a function display() that will display all information of 1 candidate. Whenever appropriate, call displayDate().*/
void display(struct CandidateTag c) // one candidate
{  
  
   int i;
   char cDump;
  printf("NAME: %s %c. %s\n", c.name.firstName, c.name.middleInitial, c.name.lastName);
  printf("BIRTHDAY: ");
  displayDate(c.birthdate);
  printf("POSITION: %s\n", c.position);
  printf("PARTY: %s\n", c.party);
  printf("---BILLS PASSED---\n");

  for (i=0; i < c.numBillsPassed; i++)
  {
    printf ("- Bill # %d-\n", i+1);
    printf ("Bill Name: %s", c.candidateBill[i].billName);
    printf ("Bill Date:");
    displayDate(c.candidateBill[i].billDate);
  }
  printf("\nRATING: %.2f%% win rate\n by: %s on ",c.rate.surveyPercentage, c.rate.surveyOrganization);
  displayDate(c.rate.surveyDate);
  printf ("\n-----\nPress ENTER key to continue");
  scanf("%c",&cDump);
}
/* 7. Create a function displayByParty() that will accept as parameter the array of candidates and the string party and will display all
candidates (and their corresponding information) who belongs to the same party. This function should call function display() as part
of the solution. Allow the user to press a key (of your choice, like Enter) to display the next candidate that is of the same party. */
void displayByParty(arrCandidates aCandidates, int nElem, char party[21])
{
  int i;
  for (i=0; i<nElem; i++)
  {
    if (party == aCandidates[i].party)
    {
      display(aCandidates[i]);
    }
  }
}
/* 8. Create a function swap() that will accept addresses of 2 candidate structures as parameter. After the function, these addresses will contain the updated values, i.e., the data in both structures will be swapped. */
void swap(struct CandidateTag * c1, struct CandidateTag * c2)
{
  struct CandidateTag temp;
  // c1 to temp
  temp.name = c1->name;
  temp.birthdate = c1->birthdate;
  strcpy(temp.position, c1->position);
  strcpy(temp.party, c1->party);
  
  *temp.candidateBill = *c1->candidateBill;
  
  temp.numBillsPassed = c1->numBillsPassed;

  //c2 to c1
  c1->name = c2->name;
  c1->birthdate = c2->birthdate;
  strcpy(c1->position, c2->position);
  strcpy(c1->party, c2->party);
  
  *c1->candidateBill = *c2->candidateBill;

  c1->numBillsPassed = c2->numBillsPassed;
  // temp to c1
  c1->name = temp.name;
  c1->birthdate = temp.birthdate;
  strcpy(c1->position, temp.position);
  strcpy(c1->party, temp.party);

  *c1->candidateBill = *temp.candidateBill;

  c1->numBillsPassed = temp.numBillsPassed;

}
/* 9. Create a function sortByRating() that will rearrange the contents of the array of candidates from the one with the highest rating
to the lowest rating. This function will not perform any display (i.e., no printf()). Part of the solution to this function is to call
function swap(). Hint: You may use the algorithm to sort an array of floating point values that we discussed before. */

// Selection Sort example
void sortByRating(arrCandidates * aCandidates, int nElem) //
{

  int i, j, min; 

  for(i=0; i<nElem-1; i++)
  {
    min=i;
    for(j=i+1; j<nElem; j++)
      if(aCandidates[min]->rate.surveyPercentage < aCandidates[j]->rate.surveyPercentage)
        min=j;

    swap(aCandidates[min],aCandidates[i]);
  } 
  // 
  
}

/* 10. Create a function sortAlphabetical() that will rearrange the contents of the array of candidates based on the last name of the
candidate. This function will not perform any display (i.e., no printf()). Part of the solution to this function is to call function swap(). */
void sortAlphabetical(arrCandidates * aCandidates, int nElem)
{
  if (nElem > 1)
  {
  int i,j;
  for (i=0; i < nElem; i++)
  {
    for (j=i+1; j < nElem; j++)
    {
      if(strcmp(aCandidates[i]->name.lastName, aCandidates[j]->name.lastName)>0)//if the string comes first
      {
        swap(aCandidates[i],aCandidates[j]);
      }
    }
  }
  }
}
/*
Candidates
  Name
    - First
    - M.I  
    - last
  Birthday
    - Month
    - Day
    - year
  Bill
   -  Bill Name
   -  Date
  Rating
   -  percentage
   -  organization
   -  Date
*/