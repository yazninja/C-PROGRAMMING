#include "corpus_LASTNAME.c"  //modify LASTNAME with your actual lastname

int 
main()
{
   sentence s;
   arrWords aWords;
   arrWords funcWords = {"the", "a", "for", "oh"};
   int nDel = 4;
   int nElem;
   string alphabetize[26][MAX];
   int counts[26];
   
   getInput(s);
   printf("%s---%d\n", s, (int)strlen(s));
   
   nElem = tokenize(aWords, s);
   printf("\nAfter tokenize():\n");
   display(aWords, nElem);
   
   del(funcWords, nDel, aWords, &nElem);
   printf("\nAfter del():\n");
   display(aWords, nElem);
   
   initIntArray(counts, 26);
   
   separate(aWords, nElem, alphabetize, counts);
   printf("\nAfter separate():\n");   
   display2D(alphabetize, counts);
   
   return 0;
}