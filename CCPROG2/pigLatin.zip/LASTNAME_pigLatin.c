#include "pig.h"

int VowelSearch(char key)
{
  char A[] = {'A','E','I','O','U','a','e','i','o','u'};
  int i;
  for(i=0;i< 10; i++)
  {
    if (key == A[i]) // found 
      return 0;
  }
    return -1;
}

void 
split(string aWords[], int *pElem, longString sentence)
{
  int i=0,j=0;
  string temp;
  
  while(i <= strlen(sentence)) 
  {
    
    if(sentence[i] == ' '|| sentence[i] == '\0')
    {
      temp[j] = '\0';
      j=0;   
      strcpy(aWords[*pElem],temp); 
      (*pElem)++; 
      i++;
    }
    else
    {
      temp[j] = sentence[i]; 
      j++;
      i++;
      
    }
  } 

}

/* Note that the original word should not be modified.  
   Apart from placing the pig latin equivalent in result, 
   the function also returns the starting address to result.
*/
char * 
toPigLatin(char * result, char * word)
{
  int i = 0,nTemp=0;
  char temp;
  strcpy(result,word);
  
  /* Check how many consonants*/
  for(i=0;i< strlen(word);i++)
  {
    if(VowelSearch(result[i]) == -1) // true if consonant
      nTemp++;
  }

  if(nTemp == strlen(word)) // all consonants
       strcat (result, "ay");
  
  else if (VowelSearch(*result) == -1) // 1 or more
  {
    i=0;
    while (VowelSearch(*result) == -1)
    {
        temp = result[0];
        for (i=0;i<strlen(word)-1;i++)
          result[i] = result[i+1];
        result[strlen(word)-1] = temp;

      
    }
    strcat (result, "ay");
    nTemp++;
  }
  
  else // vowel
    strcat (result, "way");
  
  return result; 
}
/* This function displays the contents of aWords, separating each entry 
   in the display with one space.
*/
void 
display(string aWords[], int nElem)
{
  int i;
  for (i=0;i<nElem;i++)
  {
    printf("%s ",aWords[i]);
    printf("\n");
  }
}

/* This function concatenates the contents of aWords into the
   result (thereby forming a new sentence).  Concatenation of
   words is separated by one space after each element of aWords.
*/
void 
concatenate(longString result, string aWords[], int nElem)
{
  int i;
  string temp;
  strcpy(result, "");
  for (i=0;i<nElem;i++)
  {
    strcpy(temp,aWords[i]);
    if (i < nElem-1)
      strcat(temp," ");
    strcat(result, temp);
  }
}
  