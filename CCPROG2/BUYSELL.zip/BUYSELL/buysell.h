/* 
	YOU ARE NOT ALLOWED TO CHANGE THIS FILE! 
*/

// maximum number of sellers -- to be used in declaring the SELLERS[] array
#define MAX_SELLERS 100

// maximum number of products -- to be used in declaring the PRODUCTS[] array
#define MAX_PRODUCTS 5000

// do not change the String30 typedef
typedef char String30[31];


