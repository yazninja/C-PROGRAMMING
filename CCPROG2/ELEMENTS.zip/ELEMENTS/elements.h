/* DO NOT change the contents of this file */

#define MAX_ELEMENTS 120

typedef char String[31];

typedef struct ElementTag {
	int an;              // atomic number
	String name;
	String symbol;
} ElementType;



