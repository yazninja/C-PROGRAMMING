/* 
    This is the skeleton file that you need to use as base code for the ELEMENTS problem.
	
	Encode your Name and Section below.
	    
    LASTNAME, FIRSTNAME: _____________________
    SECTION: _________
	
	DO NOT define a main() function in this file.  The main() function definition 
	is provided in the accompanying file ELEMENTS-main-LASTNAME.c.

    MAKE SURE THAT the solution/program you are submitting does not have:
       * a compilation error
	   * a compilation warning
	   * a logical error
	
	If there is a compilation error, the score will be 0 point.	   
*/


/* DO NOT CHANGE THE #include below.  You are NOT allowed to include other files. */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "elements.h"   // READ and UNDERSTAND the contents of this header file.  DO NOT change this line.


/*
	You may define other functions that can be called by the functions you need
	to accomplish the required tasks.
*/



/*
  TASK #1:  Implement the function Read_From_TextFile() which will open the text file ELEMENTS.TXT, 
  read all data contents via fscanf() and store them in an array of structures where each structure 
  is of type ElementType.  Don�t forget to close the file via fclose().  
  
  The function should return the number of structures that were stored in the array.  
  
  Pareter AE is the name of the array of structures that will store the Atomic Number, Name 
  and Symbol of all the chemical elements found in ELEMENTS.TXT.   
*/
int
Read_From_TextFile(ElementType AE[])
{

	/* implement the body of this function */
   
   	return -1;	// don't forget a return statement, modify -1 to return the logically correct value

}


/*
	TASK #2:  Implement the function Print_One_Element() which will print via printf() the 
	values of the members of one structure of type ElementType. 
		
	Display the atomic number, name and symbol in one line of output separated with at least white space.
	Output a single new line '\n' via printf().
	
	Note: You'll be the one to specify the return type, function name, parameters,
	and the body of the function.
*/







/*
   This function will print the contents of the array of structure AE.
   
   You may call this function for DEBUGGING PURPOSES only.
   
   Do NOT modify this function.   
*/
void
Print_All_Elements(ElementType AE[], int nElements)
{
	int i;
	
	for (i = 0; i < nElements; i++) {
		Print_One_Element( &AE[i] );	// Note: you'll need to implement Print_One_Element, see TASK #2 above.
	}
}


/*
	TASK #3:  Implement the function int Linear_Search() which search and return the index where 
	the search key was found in the array of elements AE[], otherwise it will return -1 (i.e., key was not found).  
	Note that the array AE[]is NOT necessarily sorted in alphabetical order by element name.

	Searching should NOT be case sensitive (i.e., it should not matter whether the letters are in 
	upper or lower case or mixed case).

	DO NOT call printf() or scanf() in this function.
*/
int 
Linear_Search(String key, ElementType AE[],  int nElements)
{
	/* implement the body of this function */
			 
   return -1;	// don't forget a return statement
}


/*
	TASK #4:  Implement the function void Sort_by_Name() such that the array AE[] will be sorted 
	in alphabetical order by the element name.   Use selection sort algorithm.  
	Refer to Chapter 1 of our Course Notes if you need to recall selection sort algorithm.	
	
	DO NOT call printf() or scanf() in this function. 
*/
void 
Sort_by_Name(ElementType AE[], int nElements)
{
	/* implement the body of this function */
	
}


/*
	TASK #6:  Implement the function int Binary_Search() which will search the key via binary search algorithm
	and return the index if was found in the AE[] array; otherwise it will return -1 (i.e., key was not found).  
	Note that since a binary search is involved, it is assumed that the 1D array AE[] is already sorted by 
	element name alphabetically.

	Searching should NOT be case sensitive (i.e., it should not matter whether letters are in upper or 
	lower case or mixed case).

	DO NOT call printf() or scanf() in this function.
*/
int 
Binary_Search(String key, ElementType AE[], int nElements)
{
	/* implement the body of this function */
	
	return -1;  // don't forget a return statement
	
}


/*
	TASK #5:  Implement the function void Write_to_TextFile() which will write to an output text 
	file named "SORTED.TXT" the contents of the sorted array AE[] - in alphabetical order by element
	name.  You'll need to use fopen(), fprintf() and fclose().
	
	Data should be written in 3 columns sequenced as Name, Symbol and Atomic Number.  For your reference
	the first three lines of the expected output file SORTED.TXT are:
	
	Actinium Ac 89
	Aluminum Al 13
	Americium Am 95
		:
		:
*/
void 
Write_to_TextFile (ElementType AE[], int nElements) 
{
	/* implement the body of this function */
	
	
}

/*******************************************************************************
    WARNING!!!   WARNING!!!   WARNING!!!    
	
	YOU ARE NOT ALLOWED TO DEFINE the main() function in this file.  

    The main() is in the accompanying main.c source file.
    
	VIOLATION OF THIS RESTRICTION WILL RESULT TO A DEDUCTION OF 10 points!		 
********************************************************************************/
