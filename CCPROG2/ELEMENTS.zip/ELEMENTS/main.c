/*
	This file contains the main() function.
	
	It is this file that you should compile.
*/


/*
   TO DO #1:  change the #include below to the file with your own lastname.  For example if your lastname
   is SHAZAM, then it should be changed to #include "ELEMENTS-SHAZAM.c".
   
*/
#include "ELEMENTS-LASTNAME.c"


/*
	This function will be used to test your solutions for the required tasks.
*/
int 
main()
{
    ElementType AE[MAX_ELEMENTS];  // 1D array of elements AE (Array of Elements)	
	int nElements;  // actual number of elements in the array AE
		
	// Test Task #1
	nElements = Read_From_TextFile(AE); // 
	
	// Test Task #2
    printf("ORIGINAL_DATA\n");
    Print_All_Elements(AE, nElements);
    printf("\n\n");
    
    // Test Task #3	
	printf("LINEAR_SEARCH_RESULTS:\n");
    printf("%d\n", Linear_Search("Oxygen", AE, nElements));
    printf("%d\n", Linear_Search("SODIUM", AE, nElements));
    printf("%d\n", Linear_Search("sodium", AE, nElements));
    printf("%d\n", Linear_Search("sODiUm", AE, nElements));
    printf("%d\n", Linear_Search("itlog", AE, nElements));     
    printf("\n\n");
    
    // Test Task #4
	Sort_by_Name(AE, nElements);
	
	printf("SORTED_LIST\n");
	Print_All_Elements(AE, nElements);
    printf("\n\n");
    
    // Test Task #5
    printf("BINARY_SEARCH_RESULTS:\n");
    printf("%d\n", Binary_Search("Oxygen", AE, nElements));
    printf("%d\n", Binary_Search("SODIUM", AE, nElements));
    printf("%d\n", Binary_Search("sodium", AE, nElements));
    printf("%d\n", Binary_Search("sODiUm", AE, nElements));
    printf("%d\n", Binary_Search("itlog", AE, nElements));     

    // Test Task #6
    Write_to_TextFile(AE, nElements); // AE is already sorted before calling the function!              
                      
	return 0;
}

