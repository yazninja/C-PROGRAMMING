#include "nGram_LASTNAME.c"  //modify LASTNAME with your actual LASTNAME
int main()
{
   sentence s;
   arrWords aWords;
   int nElem;
   int n;
   string phrases[MAX][MAX], key;
   char cDump;
   int nPhrases;
   
   
   getInput(s);
   printf("%s---%d\n", s, (int)strlen(s));
   
   nElem = tokenize(aWords, s);
   printf("\nAfter tokenize():\n");
   display(aWords, nElem);
   
   printf("\nGenerate for what n: ");
   scanf("%d", &n);
   nPhrases = genNGram(aWords, nElem, n, phrases);
   printf("\nAfter genNGram():\n");
   display2D(phrases, nPhrases, n);
   
   printf("\nEnter word to look for: ");
   scanf("%c%s", &cDump, key);
   
   printf("\nDisplaying phrases containing %s\n", key);
   displayUsage(key, phrases, nPhrases, n);
   
   return 0;
}