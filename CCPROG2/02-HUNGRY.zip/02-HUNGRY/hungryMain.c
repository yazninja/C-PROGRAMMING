/* You are free to modify the parameters to the function to 
   perform your own testing. */

#include "HUNGRY_LASTNAME.c"  /* Replace LASTNAME with your own last name */

int main()
{
	arrRecipes aRec;        //array of recipes
    int        numRec = 0,  //number of recipes
 			   index;
    
		printf("1 - Import Recipes\n");
		import("recipe.txt", aRec, &numRec);
	    displayAllRec(aRec, numRec); 
		
		printf("2 - Display Pantry\n");
		displayPantry("pantry.txt");
		
		printf("\n3 - Determine Missing Ingredients\n");
		printf("Missing from pantry to cook Siomai:\n");
		index = search("Siomai", aRec, numRec);
		if (index != -1)
	    {
            determineMissing(aRec[index], "pantry.txt", "toBuy.txt");
			// contents of toBuy.txt from your run should match expectedGrocery.txt
			
			displayPantry("toBuy.txt");  //format of pantry and grocery list files are same
	    } 
		else printf("Recipe not found\n");
		
    return 0;	
}