/* You are not allowed to change anything in this file */

#define MAX_ING  5   //maximum number of ingredients per recipe
#define MAX_REC  20  //maximum number of recipe for the array
#define MAX_STEP 10  //maximum number of steps/instructions per recipe

typedef char string[30];
typedef char longString[55];

struct ingredientTag  //also the type of data stored in each element of the binary file
{
	float  qty;       //quantity of the food item
	string unit,      //unit of measurement, assume 1 word
	       foodItem;  //food item can be more than 1 word but assume is at most 25 characters
};

struct recipeTag
{
    string               title;           //recipe title can be more than 1 word but at most 25 chars
    struct ingredientTag aIng[MAX_ING];   //at most 5 ingredients per recipe
    int                  numIng;          //number of initialized ingredients in aIng
    longString           aSteps[MAX_STEP];//at most 10 instructions to prepare recipe
	int                  numSteps;        //number of initialized steps in aSteps 
};
typedef struct recipeTag arrRecipes[MAX_REC];


//Function prototypes
void import(string sourceFile, arrRecipes aRec, int *pElem);
void displayPantry(string fname);
void determineMissing(struct recipeTag recipe, string fname, string destFile);

int getPhrase(FILE *fp, char * s);
void displayIngredient(struct ingredientTag sData);
void displayAllIng(struct ingredientTag aIng[], int nElem);
void displayRecipe(struct recipeTag rec);
void displayAllRec(arrRecipes aRec, int nElem);
int search(string title, arrRecipes aRec, int nElem);







