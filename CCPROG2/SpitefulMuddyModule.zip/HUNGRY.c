/* Modifications / updates can only be done starting from the section on Task 1 below */
#include <stdio.h>
#include <string.h>
#include "food.h"
//You are not allowed to add additional header files

//Function prototypes
void import(string sourceFile, arrRecipes aRec, int *pElem);
void displayPantry(string binFile);
void determineMissing(struct recipeTag recipe, string binFile, string destFile);
void replenish(string binFile, string sourceFile);

/* This function displays the ingredient information */
void displayIngredient(struct ingredientTag sData)
{
	      printf("%.2f %s %s\n", sData.qty, sData.unit, sData.foodItem );    
}


/* This function displays all the contents in aIng with nElem elements */
void displayAllIng(struct ingredientTag aIng[], int nElem)
{   int i;

    for (i = 0; i < nElem; i++)
 	   displayIngredient(aIng[i]);
}

/* This function displays the contents of rec */
void displayRecipe(struct recipeTag rec)
{
	int i;
	printf("%s\t\t%s\tServing: %d\n", rec.title, rec.classification, rec.serving);
	printf("\nIngredients:\n");
    displayAllIng(rec.aIng, rec.numIng);
   
    printf("\nSteps:\n");
	for (i = 0; i < rec.numSteps; i++)
	  printf("%d.) %s\n", i+1, rec.aSteps[i]);
	
	printf("\n"); 
}

/* This function displays all the recipe information in aRec with nElem elements */
void displayAllRec(arrRecipes aRec, int nElem)
{ 
   int i;
   
   for (i = 0; i < nElem;  i++)
   {
   	   printf("%d.) ", i+1);
   	   displayRecipe(aRec[i]);
   }
}

int search(string title, arrRecipes aRec, int nElem)
{
	int index = -1, i = 0;
	
	while (i < nElem && strcmp(title, aRec[i].title) != 0)
	    i++;
	if (i < nElem)
	   index = i;
	return index;
}

int main()
{
	arrRecipes aRec;
	string     fName, binFile;
    int        numRec,
               opt,
			   index;
    char       cDump;
    FILE *     pTemp;
    
	do
	{
		printf("\nMenu: \n\n");
		printf("1 - Import Recipes\n");
		printf("2 - Display Pantry\n");
		printf("3 - Replenish Pantry\n");
		printf("4 - Deterime Missing Ingredients\n");
		printf("5 - Exit Program\n\n");
		
		printf("Enter option: ");
		scanf("%d%c", &opt, &cDump);
		
		switch (opt)
		{
			case 1: printf("Enter filename of recipes: ");
			        scanf("%s%c", fName, &cDump);
			        import(fName, aRec, &numRec);
			        displayAllRec(aRec, numRec);
					break;
			case 2: printf("Enter filename of pantry contents: ");
			        scanf("%s%c", binFile, &cDump);
                    displayPantry(binFile);
					break;
			case 3: printf("Enter filename of pantry contents: ");
			        scanf("%s%c", binFile, &cDump);
					printf("Enter filename of grocery contents: ");
			        scanf("%s%c", fName, &cDump);
			        replenish(binFile, fName);
					displayPantry(binFile);
					break;
			case 4: printf("Enter recipe title: ");
			        fgets(fName, 30, stdin);
			        fName[strlen(fName)-1] = '\0';
			        index = search(fName, aRec, numRec);
			        if (index != -1)
			        {
					    printf("Enter filename of pantry contents: ");
			            scanf("%s%c", binFile, &cDump);
					    printf("Enter filename for grocery list: ");
			            scanf("%s%c", fName, &cDump);

			            determineMissing(aRec[index], binFile, fName);
					    replenish("temp.bin", fName);
					    displayPantry("temp.bin");
					    pTemp = fopen("temp.bin", "wb");  //to remove all contents of this temporary file 
					    fclose(pTemp);  
					} else printf("Recipe not found\n");
			case 5:	break;
			default: printf("Invalid option. Choose again\n");			        
		}
	} while (opt != 5);
    return 0;	
}
/*******************************************************************************************
  You CAN modify/update code ONLY after this line.  
*******************************************************************************************/

/** Task 1  [10 pts]: Implement the function import().
    This function retrieves data from the sourceFile and store them into aRec.
    
    @param sourceFile string filename where the data should be retrieved from
    @param aRec the destination location where data should be stored
    @param pElem the address where the updated number of recipes will be stored. Note that
                  it is assumed that this function should overwrite whatever is in aRec
    
    Pre-condition: [Assume that] if sourceFile exists, it follows the required format    
    
    Sample sourceFile is recipe.txt
*/
void import(string sourceFile, arrRecipes aRec, int *pElem)
{	int i;
	FILE *fp; 
	
	*pElem=0;
	fp=fopen(sourceFile,"r");
	if(fp!=NULL){
		while(fscanf(fp, "%[^\n]\n", aRec[(*pElem)].title)==1){
			fscanf(fp,"%d %[^\n]\n", &aRec[(*pElem)].serving,aRec[(*pElem)].classification);
			fscanf(fp,"Ingredients %d\n",&aRec[(*pElem)].numIng);
			for(i=0;i<aRec[(*pElem)].numIng;i++){
				fscanf(fp,"%f %s %[^\n]\n",&aRec[(*pElem)].aIng[i].qty,aRec[(*pElem)].aIng[i].unit,aRec[(*pElem)].aIng[i].foodItem);
			}
			fscanf(fp,"Steps %d\n",&aRec[(*pElem)].numSteps);
			for(i=0;i<aRec[(*pElem)].numSteps;i++){
				fscanf(fp,"%[^\n]\n",aRec[(*pElem)].aSteps[i]);
			}
			(*pElem)++;
		}
	}
	else
		printf("file cannot be found\n");
	
}

/** Task 2 [10 pts]: Implement the function displayPantry()
    This function displays the contents of the binFile on the screen.  

    @param binFile the string filename of the binary file representing contents of the pantry.
                   Note that each element of the binary file is a struct ingredient.
    
    Sample binFile is pantry.bin
*/
void displayPantry(string binFile)
{	struct ingredientTag ingredients;
	FILE *fp;
	
	fp=fopen(binFile,"rb");
	
	if(fp!=NULL){
		
		while(fread(&ingredients,sizeof(struct ingredientTag),1,fp)==1){
			printf("%.2f %s %s\n", ingredients.qty, ingredients.unit, ingredients.foodItem);	
		}
		fclose(fp);
	}
	else
		printf("\nUnable to open bin file for reading.\n");
	
}

/** Task 3: [15 pts] Implement the function determineMissing().
    This function compares data from recipe with the contents of the binFile.  If there
    is insufficient quantity or the food item does not exist in the binFile, then the
    missing quantity of the food item needed to prepare the recipe should be saved into 
    the destFile.
    
    @param recipe the structure containing the recipe information
    @param binFile the binary file of struct ingredientTag representing all food items 
                    that we already have
    @param destFile the destination filename where the missing quantity of the ingredients 
                    needed to prepare the recipe is to be stored.  If the file already exists,
                    contents in this destFile will be overwritten.
                    
    Sample contents of binFile is pantry.bin.
    Sample contents of your destFile should match the given grocery.txt, if recipe contains
	       the info on Siomai from recipe.txt and binFile is pantry.bin.
	Assume that the list of ingredients of each recipe is unique (that is there will be no 
	       two separate entries of chopped shrimp within Siomai, but there may be salt for
	       both Misua Soup and Siomai.  Assume also that binFile exists.  Should all 
	       needed ingredients be available, destFile may be created with no entries.
*/
void determineMissing(struct recipeTag recipe, string binFile, string destFile)
{	FILE *fp1,*fp2;
	int i, flag, notpart;
	struct ingredientTag ingredient;
	
	for(i=0;i<recipe.numIng;i++){
		flag=0;
		notpart=0;
		fp1=fopen(binFile,"rb");
		if(fp1!=NULL){
			
			while(fread(&ingredient,sizeof(struct ingredientTag),1,fp1)==1){
				if(strcmp(recipe.aIng[i].foodItem,ingredient.foodItem)==0){
					if(recipe.aIng[i].qty>ingredient.qty){
						ingredient.qty=recipe.aIng[i].qty-ingredient.qty;
						printf("%s %d %s %d\n", recipe.aIng[i].foodItem, recipe.aIng[i].qty, ingredient.foodItem, ingredient.qty);
						flag=1;
				 	}
					else{
						notpart=1;	
						flag=0;
					}
						
				}
				else if (strcmp(recipe.aIng[i].foodItem,ingredient.foodItem)!=0&&notpart==0){
					printf("%s %s\n", recipe.aIng[i].foodItem,ingredient.foodItem);
				 	ingredient=recipe.aIng[i];
				 	flag=1;
				}
			}
			fclose(fp1);	
		}
		else
			printf("\nUnable to open bin file for reading\n");
		
		printf("%s %.2f\n",ingredient.foodItem, ingredient.qty);
		
		if(flag==1){
			fp2=fopen(destFile,"rb+");
			if(fp2!=NULL){
				fseek(fp2,0,SEEK_END);
				fwrite(&ingredient,sizeof(struct ingredientTag),1,fp2);
				fclose(fp2);
			}
			else
				printf("\nUnable to open bin file for reading\n");	
		}
	
	}
}	

/**  Task 4 [15 pts]: Implement the function replenish().
     This function updates the contents of binFile by adding the quantity of the existing food
     items already in the file or adding the entry of the food item in the file if it does not 
	 exist yet.
	 
	 @param binFile the string filename of the binary file of struct ingredient
	 @param sourceFile the string filename of the text file representing (maybe) what we have 
	                   bought from the supermarket to be added to the pantry
	
	Do NOT assume that the sourceFile contains unique ingredients.
*/
void replenish(string binFile, string sourceFile) 
{  	FILE *fp1, *fp2;
	struct ingredientTag ingredient;
	
	fp1=fopen(sourceFile,"r");
	if(fp1!=NULL){
		
		fclose(fp1);
	}
	
} 



