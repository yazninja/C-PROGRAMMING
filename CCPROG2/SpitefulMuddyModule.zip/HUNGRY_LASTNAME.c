/** Problem: HUNGRY
   
    Name   : 
    Section: 

*/

/* Modifications / updates can only be done starting from the section on Task 1 below */
#include <stdio.h>
#include <string.h>
#include "food.h"
//You are not allowed to add additional header files

/* This function gets a series of characters until the '\n' 
   from the already opened text file.  It is assumed that the retrieved
   set of characters can fit in the capacity of the container referred to
   by s.  It is also assumed that a '\n' precedes the EOF.
   
   If the file position is already at the EOF, the function returns 0.  If
   there is a phrase retrieved, the function returns 1.
   
   This is useful if you plan to read a string that is more than one word 
   (could be a phrase or a sentence).  
*/
int 
getPhrase(FILE *fp, char * s)
{
   char ch;
   int i = 0, res;
   
   
   do
   {
      res = fscanf(fp, "%c", &ch);
	  if (res == 1 && ch != '\n')
	  {  s[i] = ch;
	     i++;
	     s[i] = '\0';
	  }
   }while (res == 1 && ch != '\n');  
   return res;   
}

/* This function displays the ingredient information */
void 
displayIngredient(struct ingredientTag sData)
{
	      printf("%.2f %s %s\n", sData.qty, sData.unit, sData.foodItem );    
}


/* This function displays all the contents in aIng with nElem elements */
void 
displayAllIng(struct ingredientTag aIng[], int nElem)
{   int i;

    for (i = 0; i < nElem; i++)
 	   displayIngredient(aIng[i]);
}

/* This function displays the contents of rec */
void 
displayRecipe(struct recipeTag rec)
{
	int i;
	printf("%s", rec.title);
	printf("\nIngredients:\n");
    displayAllIng(rec.aIng, rec.numIng);
   
    printf("\nSteps:\n");
	for (i = 0; i < rec.numSteps; i++)
	  printf("%d.) %s\n", i+1, rec.aSteps[i]);
	
	printf("\n"); 
}

/* This function displays all the recipe information in aRec with nElem elements */
void 
displayAllRec(arrRecipes aRec, int nElem)
{ 
   int i;
   
   for (i = 0; i < nElem;  i++)
   {
   	   printf("%d.) ", i+1);
   	   displayRecipe(aRec[i]);
   }
}

/* This function returns the index where the title matches the recipe title
   in aRec.  If not found, the function returns -1.
*/
int 
search(string title, arrRecipes aRec, int nElem)
{
	int index = -1, i = 0;
	
	while (i < nElem && strcmp(title, aRec[i].title) != 0)
	    i++;
	if (i < nElem)
	   index = i;
	return index;
}


/*******************************************************************************************
  You CAN modify/update code ONLY after this line.  
*******************************************************************************************/

/** Task 1  [15 pts]: Implement the function import().
    This function retrieves data from the text file with the name sourceFilename
	and store them into aRec.
	If aRec already contains some entries, import() will just ADD entries from 
	the file to aRec, as long as aRec can still accomodate the data.
 
	Note: (1) You are allowed to use fscanf(), fgets(), and getPhrase().
	      (2) There should be no printf() statements in this function.
	      (3)[Optional] If you wish to create/call an additional function, this
	      additional function's task is to read 1 line of text from the file
		  and store that as a struct ingredientTag.
 
    @param sourceFilename- string filename of the text file where the data 
	                      should be retrieved from
    @param aRec - the destination location where data should be stored
    @param pElem - the address where the updated number of recipes will be stored. Note that
                  it is assumed that this function should overwrite whatever is in aRec
    
    The format of the file is:
	    <recipe title>\n
		Ingredients<space><number of ingredients>\n
	    <qty><space><unit><space><foodItem1>\n
	    <qty><space><unit><space><foodItem2>\n
            :::
	    <qty><space><unit><space><foodItemM>\n
	    Steps<space><number of steps>\n
		<step1>\n
		<step2>\n
		   :::
		<stepX>\n
        \n
		   :::
	    <recipe title>\n
		Ingredients<space><number of ingredients>\n
	    <qty><space><unit><space><foodItem1>\n
	       :::
	    <qty><space><unit><space><foodItemN>\n
	    Steps<space><number of steps>\n
		<step1>\n
		   :::
		<stepY>\n
        EOF
	
    Pre-condition: [Assume that] if sourceFile exists, it follows the required format    
    
    Sample sourceFile is recipe.txt
*/
void import(string sourceFile, arrRecipes aRec, int *pElem)
{	int i;
	FILE *fp; 
	
	*pElem=0;
	fp=fopen(sourceFile,"r");
	if(fp!=NULL){
		while(fscanf(fp, "%[^\n]\n", aRec[(*pElem)].title)==1){
      printf("'RECIPE GOES HERE: %s'\n",aRec[(*pElem)].title);
			fscanf(fp,"Ingredients %d\n",&aRec[(*pElem)].numIng);
			for(i=0;i<aRec[(*pElem)].numIng;i++){
				fscanf(fp,"%f %s %[^\n]\n",&aRec[(*pElem)].aIng[i].qty,aRec[(*pElem)].aIng[i].unit,aRec[(*pElem)].aIng[i].foodItem);
			}
			fscanf(fp,"Steps %d\n",&aRec[(*pElem)].numSteps);
			for(i=0;i<aRec[(*pElem)].numSteps;i++){
				fscanf(fp,"%[^\n]\n",aRec[(*pElem)].aSteps[i]);
			}
			(*pElem)++;
		}
	}
	else
		printf("file cannot be found\n");
	
}

/** Task 2 [15 pts]: Implement the function displayPantry()
                     This function displays the contents of the text file with 
					 the name fname on the screen. 
                     There is no indicated limit to the number of lines in this file.					 
	Requirement: (1) You are NOT allowed to have any printf() statements in this 
	             function. 
				 (2) You are REQUIRED to call function displayIngredient() as
				  part of your solution.
				 (3) You are NOT allowed to declare an array of structure in this 
				     function.
					  
	
	Note: (1) You can use fscanf(), fgets(), and getPhrase().
	      (2) [Optional] If you wish to create/call an additional function, this
	      additional function's task is to read 1 line of text from the file
		  and store that as a struct ingredientTag.  This function should also NOT
		  have any array of structure in the parameter or in its local variables.
	           
    @param fname -  string filename of the text file representing contents of the pantry.
                   
	Note that each line in the text file signifies data similar to struct ingredient.
	The format of the file is:
	    <qty><space><unit><space><foodItem>\n
	    <qty><space><unit><space><foodItem>\n
            :::
	    <qty><space><unit><space><foodItem>\n
	    EOF
    
	Pre-condition: [Assume that] if the file exists, the file follows the correct format.
	
    Sample fname is pantry.txt
*/
void 
displayPantry(string fname)
{	
  struct ingredientTag ingredients;
	FILE *fp;
	
	fp=fopen(fname,"r");
	
	if(fp!=NULL){
		
		while(fscanf(fp,"%f%s %[^\n]",&ingredients.qty, ingredients.unit,ingredients.foodItem)==3){
        printf("%.2f %s %s\n", ingredients.qty, ingredients.unit, ingredients.foodItem);
				
		}
		fclose(fp);
	}
	else
		printf("\nUnable to open bin file for reading.\n");
	

}

/** Task 3: [20 pts] Implement the function determineMissing().
    This function compares data from recipe with the contents of the text file
	with name fname.  If there is insufficient quantity or the food item does not
	exist in the fname, then the missing quantity of the food item needed to 
	prepare the recipe should be saved into the destination text file with 
	name destFilename.
	
	Requirement: (1) Storing data into the destination text file destFilename should 
	                 follow the format indicated in Task 2.  There should be
					 NO unnecessary spaces or extraneous characters.
				 (2) You are NOT allowed to have any printf() statements in this function.
                 
	Note: (1) You can use fscanf(), fprintf(), fgets(), and getPhrase().
	      (2) [Optional] If you wish to create/call an additional function, this
	      additional function's task is to read 1 line of text from the file
		  and store that as a struct ingredientTag.
    
    @param recipe - the structure containing the recipe information
    @param fname - the text file representing the contents of the pantry. The format of
	             this file is discussed in Task 2. 
    @param destFilename- the destination text file where the missing quantity of the ingredients 
                    needed to prepare the recipe is to be stored.  If the file already exists,
                    contents in this destFile will be overwritten. This file format is 
					similar to that of the pantry.  This resulting text file will
					represent the ingredients to buy.
                    
    Sample contents of fname is pantry.txt.
    Sample contents of your destFilename should match the given expectedGrocery.txt, if recipe contains
	       the info on Siomai from recipe.txt and fname is pantry.txt.
	Assume that the list of ingredients of each recipe is unique (that is, there will be no 
	       two separate entries of chopped shrimp within Siomai, but there may be salt for
	       both Misua Soup and Siomai.  Assume also that fname exists.  Should all 
	       needed ingredients be available, destFile may be created with no entries.
*/
void
determineMissing(struct recipeTag recipe, string fname, string destFilename)
{
FILE *fp1,*fp2;
	int i, flag, notpart;
	struct ingredientTag ingredient;
	
	for(i=0;i<recipe.numIng;i++){
		flag=0;
		notpart=0;
		fp1=fopen(fname,"r");
		if(fp1!=NULL){
			
			while(fscanf(fp1,"%f %s %s",&ingredient.qty, ingredient.unit, ingredient.foodItem)==1){
				if(strcmp(recipe.aIng[i].foodItem,ingredient.foodItem)==0){
					if(recipe.aIng[i].qty>ingredient.qty){
						ingredient.qty=recipe.aIng[i].qty-ingredient.qty;
						printf("%s %f %s %f\n", recipe.aIng[i].foodItem, recipe.aIng[i].qty, ingredient.foodItem, ingredient.qty);
						flag=1;
				 	}
					else{
						notpart=1;	
						flag=0;
					}
						
				}
				else if (strcmp(recipe.aIng[i].foodItem,ingredient.foodItem)!=0&&notpart==0){
					printf("%s %s\n", recipe.aIng[i].foodItem,ingredient.foodItem);
				 	ingredient=recipe.aIng[i];
				 	flag=1;
				}
			}
			fclose(fp1);	
		}
		else
			printf("\nUnable to open bin file for reading\n");
		
		printf("%s %.2f\n",ingredient.foodItem, ingredient.qty);
		
		if(flag==1){
			fp2=fopen(destFilename,"r");
			if(fp2!=NULL){
				fseek(fp2,0,SEEK_END);
				fwrite(&ingredient,sizeof(struct ingredientTag),1,fp2);
				fclose(fp2);
			}
			else
				printf("\nUnable to open bin file for reading\n");	
		}
	
	}
}


/***** The main() should not included in this file *******/
