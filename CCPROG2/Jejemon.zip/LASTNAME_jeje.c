#include <stdio.h>
#include <string.h>

#define MAX 15

typedef char string[MAX + 3];

void 
toJejemon(string str)
{
  int i;
  int repeat = 0; // so that S replace does not loop infinitely
for (i=0; i < strlen(str); i++)
{
  if (str[i] == 'o'|| str[i] == 'O') // rule 1
  { 
    if (i == strlen(str)-1) // rule 3
    {
      strcat (str,"wz");
    }
    str[i] = '0';
  }
    
  else if (str[i] == 'e' || str[i] == 'E') // rule 2
    str[i] = '3';
    
  if (i == strlen(str)-1 && repeat == 0) // last letter
  {
    if (str[i] == 's' || str[i] == 'S') // rule 4
    {
      str[i] = 'e';
      strcat (str,"s");
      repeat = 1;
    }   
  }
  // rule 5
  if(i % 2 == 1) // odd 
  {
    if(str[i] >= 'a' && str[i] <= 'z') // lowercase
      str[i] = str[i] - 32;
  }
  else if(i % 2 == 0) // even 
  {
    if(str[i] >= 'A' && str[i] <= 'Z') // char is uppercase
      str[i] = str[i] + 32;
  }
}
}


