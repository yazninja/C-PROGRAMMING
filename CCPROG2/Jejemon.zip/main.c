#include "LASTNAME_jeje.c"   //replace this with the actual name of your Jejemon solution

int 
main()
{
   string input;

   printf("Enter string: ");
   scanf("%s", input);
   
   printf("%s in Jejemon is ", input);
   
   toJejemon(input);
 
   printf("%s\n", input); 

   return 0;
}


