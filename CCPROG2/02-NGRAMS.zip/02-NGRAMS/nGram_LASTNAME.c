/** Hands on 1
  * Problem 2 : N-Grams and Co-occurring words
  *
  * Name: <replace this with Lastname, Firstname>
  * Section: <replace this with your section>
  */

#include "ngram.h"    //Do NOT remove this line

//Do NOT modify this function
void 
getInput(sentence s)
{
   char ch;
   int i = 0;
   
   do
   {
      scanf("%c", &ch);
	  if (ch != '\n')
	  {  s[i] = ch;
	     i++;
	     s[i] = '\0';
	  }
   }while (i < LEN2 && ch != '\n');   
}

//Do NOT modify this function
void 
display(arrWords aWords, int nElem)
{	int i;
	for (i = 0; i < nElem; i++)
		printf("-%s-", aWords[i]);
	printf("\n");
}

/* To Do: Implement this function.  [15 points]
   Requirement: Store each word in s to aWords. Do not assume that 
                there is only 1 space that separates the words. Assume
				that there are only letters and spaces in s. Note that
				spaces should not be part of any content in aWords.
				
   @param aWords is the destination container (array)
   @param s is assumed to contain at least one word.
   @return the total number of entries in aWords at the end of the function
*/
int
tokenize(arrWords aWords, sentence s)
{	//your code


}

/* To Do: Implement this function.   [15 points]
   Requirement: From the list of words aWords with nElem number of 
                elements, copy n number of entries from aWords to 
				every row of phrases. In the end, number of rows of 
				n entries (columns) should be returned by the function.
 
   For examples: if aWords = {"the", "quick", "brown", "fox", "jumped"},
                   nElem = 5, n = 3, then the function will produce the 
				   following:
				 phrases = { {"the", "quick", "brown"},
					        {"quick", "brown", "fox"},
				            {"brown", "fox", "jumped"}} 
				 returns 3 representing 3 rows initialized in phrases
				 
				 Using the same contents for aWords and nElem, but if n = 4,
				   the function will produce the following:
				 phrases = { {"the", "quick", "brown", "fox"},
					         {"quick", "brown", "fox", "jumped"}} 
				 returns 2
				 
	@param aWords is the array containing 1 word per element
	@param nElem is the number of elements in aWords
	@param n is the number of words per phrase
	@param phrases is the 2D array of words consisting of n words per row
	@return the number of rows initialized in phrases
*/
int 
genNGram(arrWords aWords, int nElem, int n,
         string phrases[][MAX])
{
   // your code

}

/* To Do: Implement this function.   [10 pts]
   Requirement: Call function display() as part of your solution.
                No printf() statements allowed in this function.
				
   @param phrases is the 2D array of words to be displayed
   @param nPhrases is the number of initialized rows in phrases
   @param nWords is the number of initialized columns in phrases
*/
void
display2D(string phrases[][MAX], int nPhrases, int nWords)
{
   // your code

}

/* To Do: Implement this function.   [10 pts]
   Requirement: This function displays all rows in phrases that 
                contain key.  Only exact matches will be displayed.
				Meaning, if it is part of another word or is in a 
				different case (not same capitalization), it will 
				not be included in the display. 
				Call function display() as part of your solution.
                No printf() statements allowed in this function.
				
   @param key is the word being looked for in phrases
   @param phrases is the 2D array of words to search from
   @param nPhrases is the number of initialized rows in phrases
   @param nWords is the number of initialized columns in phrases
*/
void 
displayUsage(string key, string phrases[][MAX], int nPhrases, int nWords)
{
   // your code


}
