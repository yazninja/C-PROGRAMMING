/** Hands on 1
  * Problem 1 : Corpus Preprocessing
  *
  * Name: <replace this with Lastname, Firstname>
  * Section: <replace this with your section>
  */

#include "corpus.h"    //Do NOT remove this line

//Do NOT modify this function
void 
getInput(sentence s)
{
   char ch;
   int i = 0;
   
   do
   {
      scanf("%c", &ch);
	  if (ch != '\n')
	  {  s[i] = ch;
	     i++;
	     s[i] = '\0';
	  }
   }while (i < LEN2 && ch != '\n');   
}

//Do NOT modify this function
void 
display(arrWords aWords, int nElem)
{	int i;
    printf("Count = %d:\n", nElem);
	for (i = 0; i < nElem; i++)
		printf("-%s-", aWords[i]);
	printf("\n");
}

//Do NOT modify this function
void 
initIntArray(int arr[], int nElem)
{	int i;
	for (i = 0; i < nElem; i++)
		arr[i] = 0;
}

/* To Do: Implement this function.  [15 pts]
   Requirement: Store each word in s to aWords. Do not assume that 
                there is only 1 space that separates the words. Assume
				that there are only letters and spaces in s. Note that
				spaces should not be part of any content in aWords.
				
   @param aWords is the destination container (array)
   @param s is assumed to contain at least one word.
   @return the total number of entries in aWords at the end of the function
*/
int 
tokenize(arrWords aWords, sentence s)
{ 
  int i, j = 0, nElem = 0;
	
	//included the index where the '\0' is to include the last word
	for (i = 0; i <= strlen(s); i++)
	   if (s[i] != ' ' && s[i] != '\0')
	   {
          aWords[nElem][j] = s[i];
		      j++;
	   }
	   else
	   {
      if (s[i+1] != ' ' && i != 0)
      {
        aWords[nElem][j] = '\0';
		    j = 0;
		    (nElem)++;
      }
		   
	   }


     return nElem;
}

/* To Do: Implement this function.   [15 pts]
   Requirement: From the list of words aWords with nElem number of 
                elements, copy words that start with the same character 
				in the same row.  That is, all that start with 'A' or 'a'
				should be placed in row index 0 of alphabetize, those that
				start with 'B' or 'b' should be stored in row index 1 of
				alphabetize and so on. The array counts will contain the 
				number of words in each of the row in alphabetize. Note
				that there is no need to check if the same word already
				is included, just add them into the 2D array alphabetize; 
				so alphabetize can contain duplicate entries. Assume that
				there can be at most 15 words that start with the same letter
 
   For example: if aWords = {"Jack", "and", "jill", "went", "up"},
                   nElem = 5, then the function will produce the 
				   following:
				 alphabetize[0] = {"and"} ,
                 alphabetize[9] = {"Jack", "jill"},
                 alphabetize[20] = {"up"},
				 alphabetize[22] = {"went"}, 
				    while the rest of the elements in alphabetize do not
				    have any entries 
				 The 1st 10 elements of counts = { 1, 0,0,0,0,0,0,0, 0, 2};
				    the value stored in counts representing the number of words
					starting with u and w are 1 , while the rest contain 0.

    @param aWords is the array containing 1 word per elements
	@param nElem is the number of elements in aWords
	@param alphabetize is the 2D array where the words with the same 
	            first letter are stored per row
	@param counts is the array of integers containing the number of initialized 
	            elements per row 
*/
void 
separate(arrWords aWords, int nElem, 
         string alphabetize[][MAX], int counts[])
{
  int i,j,k;
  for (i=0; i < 26; i++)
  {
    k=0;
    for (j=0; j < nElem; j++)
    {
      if(aWords[j][0] == 'A'+ i || aWords[j][0] == 'a'+ i)
      strcpy(alphabetize[i][k],aWords[j]);
      k++;
    }
    counts[i] = k;
  }

}

/* To Do: Implement this function.   [10 pts]
   Requirement: Call function display() as part of your solution.
                No printf() statements allowed in this function.
				
   @param phrases is the 2D array of words to be displayed
   @param counts is the number of initialized columns in phrases
*/
void
display2D(string phrases[][MAX], int counts[])
{
   int i,j; 
  for(i=0; i < 26; i++)
    for(j=0; j < counts[i]; j++)
      display(phrases[j],counts[i]);

}

/* To Do: Implement this function.  [10 pts]
   Requirement: This function deletes all words that matches
                those in array toDel. Only exact matches are to
				be removed (also means same case / capitalization).
				Note that by the end of this function, *pElem
				should also contain the updated number of elements
				in aWords.
				
   @param toDel is the set of words that are to be removed from aWords if they are found
   @param nDel is the number of words in toDel
   @param aWords is the array of words to delete from
   @param pElem is the address referring to the number of elements in aWords
*/
void 
del(arrWords toDel, int nDel, arrWords aWords, int *pElem)
{
  int i,j,k;
  for(i=0; i < nDel; i++)
  {
    for(j=0; j < *pElem; j++)
    if(strcmp(toDel[nDel],aWords[j]) == 0)
    {
      for(k=j-1; k < *pElem-1; k++)
        {
            strcpy(aWords[k],aWords[k + 1]);
        }
    }
  }

}

