#include <stdio.h>
#include <string.h>

#define LEN1 20
#define LEN2 256
#define MAX  15

typedef char string[LEN1+1];
typedef char sentence[LEN2];
typedef string arrWords[MAX]; 

void getInput(sentence s);
int tokenize(arrWords aWords, sentence s);
void display(arrWords aWords, int nElem);
void initIntArray(int arr[], int nElem);
void separate(arrWords aWords, int nElem, string alphabetize[][MAX], int counts[]);
void display2D(string phrases[][MAX], int counts[]);
void del(arrWords toDel, int nDel, arrWords aWords, int *pElem);