#include <stdio.h>
#include <string.h>

#define LEN1 20
#define LEN2 256
#define MAX  15

typedef char string[LEN1+1];
typedef char sentence[LEN2];
typedef string arrWords[MAX]; 

void getInput(sentence s);
int tokenize(arrWords aWords, sentence s);
void display(arrWords aWords, int nElem);
int genNGram(arrWords aWords, int nElem, int n, string phrases[][MAX]);
void display2D(string phrases[][MAX], int nPhrases, int nWords);
void displayUsage(string key, string phrases[][MAX], int nPhrases, int nWords);
